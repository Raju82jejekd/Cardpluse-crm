package com.example.data.ai

import kotlinx.coroutines.delay

sealed interface DocumentScanResult {
    data class Success(
        val fullName: String,
        val panNumber: String,
        val dateOfBirth: String,
        val isSamplePlaceholder: Boolean,
        val notice: String
    ) : DocumentScanResult

    data class Error(val message: String) : DocumentScanResult
}

interface DocumentScanRepository {
    suspend fun extractPanDetails(imageBytes: ByteArray?): DocumentScanResult
}

/**
 * Placeholder implementation used when Firebase AI Logic is not enabled.
 * Clearly labels extracted values as sample responses and displays an in-app
 * notice that live Gemini Vision extraction requires Firebase AI Logic.
 */
class PlaceholderDocumentScanRepository : DocumentScanRepository {

    private val sampleDocuments = listOf(
        Triple("Raghavendra Joshi", "BKLPJ7429Q", "17/06/1991"),
        Triple("Neha Sharma", "CMRPS5814D", "24/10/1993"),
        Triple("Aditya Verma", "DGHPV3902L", "09/03/1989")
    )

    private var cursor = 0

    override suspend fun extractPanDetails(imageBytes: ByteArray?): DocumentScanResult {
        delay(850L)
        val sample = sampleDocuments[cursor % sampleDocuments.size]
        cursor++
        return DocumentScanResult.Success(
            fullName = sample.first,
            panNumber = sample.second,
            dateOfBirth = sample.third,
            isSamplePlaceholder = true,
            notice = "Sample extraction applied (AI features require Firebase). Enable Firebase AI Logic to run live Gemini Vision OCR on uploaded PAN/ID images."
        )
    }
}
