package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.NumberFormat
import java.util.Locale

enum class ApplicationStatus(
    val label: String,
    val shortLabel: String,
    val isInProgress: Boolean
) {
    QDE_DONE("QDE Done", "QDE Done", true),
    KYC_PENDING("KYC Pending", "KYC Pending", true),
    DIP_HOLD("DIP Hold", "DIP Hold", true),
    APPROVED("Approved", "Approved", false),
    DECLINED("Declined", "Declined", false);

    companion object {
        fun fromName(name: String): ApplicationStatus =
            entries.firstOrNull { it.name == name } ?: QDE_DONE
    }
}

enum class EmploymentType(val label: String) {
    SALARIED("Salaried"),
    SELF_EMPLOYED("Self-Employed");

    companion object {
        fun fromName(name: String): EmploymentType =
            entries.firstOrNull { it.name == name } ?: SALARIED
    }
}

enum class CardTier(
    val title: String,
    val tierLabel: String,
    val minMonthlyIncome: Long,
    val annualFeeLabel: String,
    val highlight: String,
    val creditLimitHint: String
) {
    BASIC(
        title = "CardPulse Classic",
        tierLabel = "Basic",
        minMonthlyIncome = 20_000L,
        annualFeeLabel = "Lifetime Free",
        highlight = "1.5% reward points on groceries, UPI & fuel waiver",
        creditLimitHint = "Up to ₹75,000 limit"
    ),
    CASHBACK(
        title = "CardPulse Cashback+",
        tierLabel = "Cashback",
        minMonthlyIncome = 40_000L,
        annualFeeLabel = "₹499 / yr",
        highlight = "5% flat cashback on online shopping & utility bills",
        creditLimitHint = "Up to ₹2,00,000 limit"
    ),
    TRAVEL(
        title = "CardPulse Miles Edge",
        tierLabel = "Travel",
        minMonthlyIncome = 75_000L,
        annualFeeLabel = "₹1,499 / yr",
        highlight = "8 domestic lounge visits & 4X air miles on bookings",
        creditLimitHint = "Up to ₹4,50,000 limit"
    ),
    PREMIUM(
        title = "CardPulse Signature Reserve",
        tierLabel = "Premium",
        minMonthlyIncome = 125_000L,
        annualFeeLabel = "₹4,999 / yr",
        highlight = "Unlimited airport lounges, 1.5% forex & concierge",
        creditLimitHint = "Up to ₹10,00,000 limit"
    );

    companion object {
        fun fromName(name: String): CardTier =
            entries.firstOrNull { it.name == name } ?: BASIC

        fun recommendedForIncome(monthlyIncome: Long, hasExistingCard: Boolean): CardTier {
            val effectiveIncome = if (hasExistingCard) (monthlyIncome * 1.1).toLong() else monthlyIncome
            return when {
                effectiveIncome >= PREMIUM.minMonthlyIncome -> PREMIUM
                effectiveIncome >= TRAVEL.minMonthlyIncome -> TRAVEL
                effectiveIncome >= CASHBACK.minMonthlyIncome -> CASHBACK
                else -> BASIC
            }
        }

        fun eligibleTiers(monthlyIncome: Long, hasExistingCard: Boolean): List<CardTier> {
            val effectiveIncome = if (hasExistingCard) (monthlyIncome * 1.1).toLong() else monthlyIncome
            val eligible = entries.filter { effectiveIncome >= it.minMonthlyIncome }
            return eligible.ifEmpty { listOf(BASIC) }
        }
    }
}

@Entity(tableName = "card_applications")
data class CardApplicationEntity(
    @PrimaryKey val applicationId: String,
    val fullName: String,
    val mobileNumber: String,
    val panNumber: String,
    val dateOfBirth: String,
    val city: String,
    val pincode: String,
    val employmentType: String,
    val companyName: String,
    val netMonthlyIncome: Long,
    val existingCreditCard: Boolean,
    val selectedCardTier: String,
    val addOnCardRequested: Boolean,
    val addOnHolderName: String,
    val status: String,
    val fieldRemarks: String,
    val dipReason: String,
    val kycDocumentUri: String,
    val dipDocumentUri: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long
) {
    val statusEnum: ApplicationStatus
        get() = ApplicationStatus.fromName(status)

    val employmentTypeEnum: EmploymentType
        get() = EmploymentType.fromName(employmentType)

    val cardTierEnum: CardTier
        get() = CardTier.fromName(selectedCardTier)

    val remarksList: List<String>
        get() = fieldRemarks.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
}

data class SalesExecutiveProfile(
    val name: String = "Rohan Deshmukh",
    val role: String = "Senior Field Sales Executive",
    val employeeCode: String = "EMP-4092",
    val territoryName: String = "Mumbai West — Bandra & Andheri",
    val dailyTarget: Int = 10
)

fun formatIndianRupees(amount: Long): String {
    val formatter = NumberFormat.getNumberInstance(Locale("en", "IN"))
    return "₹${formatter.format(amount)}"
}
