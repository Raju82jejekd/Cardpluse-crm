package com.example.data.repository

import com.example.data.local.CardApplicationDao
import com.example.data.model.ApplicationStatus
import com.example.data.model.CardApplicationEntity
import com.example.data.model.CardTier
import com.example.data.model.EmploymentType
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class ApplicationRepository(
    private val dao: CardApplicationDao
) {
    val allApplications: Flow<List<CardApplicationEntity>> = dao.getAllApplications()

    suspend fun ensureSeedData() {
        if (dao.count() == 0) {
            dao.insertAll(buildInitialIndianSampleRecords())
        }
    }

    suspend fun createApplication(application: CardApplicationEntity) {
        dao.upsert(application)
    }

    suspend fun updateStatus(
        applicationId: String,
        newStatus: ApplicationStatus,
        note: String? = null,
        clearDipReason: Boolean = false
    ) {
        val current = dao.getById(applicationId) ?: return
        val timestamp = formatTimestamp(System.currentTimeMillis())
        val updatedRemarks = buildString {
            if (current.fieldRemarks.isNotBlank()) {
                append(current.fieldRemarks.trim())
                append("\n")
            }
            val actionNote = note?.takeIf { it.isNotBlank() }
                ?: "Status updated to ${newStatus.label}"
            append("[$timestamp] $actionNote")
        }
        val nextDipReason = when {
            clearDipReason || newStatus != ApplicationStatus.DIP_HOLD -> ""
            current.dipReason.isBlank() -> "Pending field document clarification"
            else -> current.dipReason
        }
        dao.updateApplicationProgress(
            applicationId = applicationId,
            status = newStatus.name,
            remarks = updatedRemarks,
            dipReason = nextDipReason,
            dipDocumentUri = current.dipDocumentUri,
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun addFieldRemark(applicationId: String, remarkText: String) {
        val trimmed = remarkText.trim()
        if (trimmed.isEmpty()) return
        val current = dao.getById(applicationId) ?: return
        val timestamp = formatTimestamp(System.currentTimeMillis())
        val updatedRemarks = buildString {
            if (current.fieldRemarks.isNotBlank()) {
                append(current.fieldRemarks.trim())
                append("\n")
            }
            append("[$timestamp] Field Note: $trimmed")
        }
        dao.updateApplicationProgress(
            applicationId = applicationId,
            status = current.status,
            remarks = updatedRemarks,
            dipReason = current.dipReason,
            dipDocumentUri = current.dipDocumentUri,
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun resolveDipHold(
        applicationId: String,
        reUploadedDocUri: String,
        resolutionRemark: String
    ) {
        val current = dao.getById(applicationId) ?: return
        val timestamp = formatTimestamp(System.currentTimeMillis())
        val note = resolutionRemark.trim().ifEmpty {
            "Fresh verification document re-uploaded via mobile CRM"
        }
        val updatedRemarks = buildString {
            if (current.fieldRemarks.isNotBlank()) {
                append(current.fieldRemarks.trim())
                append("\n")
            }
            append("[$timestamp] DIP Resolved -> KYC Pending: $note")
        }
        dao.updateApplicationProgress(
            applicationId = applicationId,
            status = ApplicationStatus.KYC_PENDING.name,
            remarks = updatedRemarks,
            dipReason = "",
            dipDocumentUri = reUploadedDocUri.ifBlank { current.dipDocumentUri },
            updatedAt = System.currentTimeMillis()
        )
    }

    companion object {
        private val PAN_REGEX = Regex("^[A-Z]{5}[0-9]{4}[A-Z]$")
        private val MOBILE_REGEX = Regex("^[6-9][0-9]{9}$")
        private val PINCODE_REGEX = Regex("^[1-9][0-9]{5}$")
        private val DOB_REGEX = Regex("^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/(19|20)[0-9]{2}$")

        fun isValidPan(pan: String): Boolean = PAN_REGEX.matches(pan.trim().uppercase())
        fun isValidMobile(mobile: String): Boolean = MOBILE_REGEX.matches(mobile.trim())
        fun isValidPincode(pincode: String): Boolean = PINCODE_REGEX.matches(pincode.trim())
        fun isValidDob(dob: String): Boolean = DOB_REGEX.matches(dob.trim())

        fun generateApplicationId(): String {
            val number = Random.nextInt(1000, 9999)
            return "CP-2026-$number"
        }

        fun formatTimestamp(epochMs: Long): String {
            val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH)
            return sdf.format(Date(epochMs))
        }

        private fun buildInitialIndianSampleRecords(): List<CardApplicationEntity> {
            val now = System.currentTimeMillis()
            val hour = 3_600_000L
            return listOf(
                CardApplicationEntity(
                    applicationId = "CP-2026-8419",
                    fullName = "Ananya Kulkarni",
                    mobileNumber = "9820411892",
                    panNumber = "BNZPK4821M",
                    dateOfBirth = "14/08/1991",
                    city = "Mumbai",
                    pincode = "400050",
                    employmentType = EmploymentType.SALARIED.name,
                    companyName = "Tata Consultancy Services",
                    netMonthlyIncome = 148_000L,
                    existingCreditCard = true,
                    selectedCardTier = CardTier.PREMIUM.name,
                    addOnCardRequested = true,
                    addOnHolderName = "Siddharth Kulkarni",
                    status = ApplicationStatus.APPROVED.name,
                    fieldRemarks = "[21 Nov, 09:40 AM] Office verification completed at BKC campus\n[21 Nov, 11:15 AM] E-KYC & CIBIL 792 cleared — Card approved",
                    dipReason = "",
                    kycDocumentUri = "",
                    dipDocumentUri = "",
                    createdAtEpochMs = now - 5 * hour,
                    updatedAtEpochMs = now - 1 * hour
                ),
                CardApplicationEntity(
                    applicationId = "CP-2026-8414",
                    fullName = "Vikramaditya Nair",
                    mobileNumber = "9845120934",
                    panNumber = "AGTPN7390K",
                    dateOfBirth = "26/02/1988",
                    city = "Mumbai",
                    pincode = "400053",
                    employmentType = EmploymentType.SELF_EMPLOYED.name,
                    companyName = "Nair MedTech Solutions Pvt Ltd",
                    netMonthlyIncome = 112_000L,
                    existingCreditCard = true,
                    selectedCardTier = CardTier.TRAVEL.name,
                    addOnCardRequested = false,
                    addOnHolderName = "",
                    status = ApplicationStatus.DIP_HOLD.name,
                    fieldRemarks = "[21 Nov, 08:50 AM] QDE submitted at Andheri West branch\n[21 Nov, 10:25 AM] Underwriting DIP Hold flagged: PAN photo glare obscures signature",
                    dipReason = "PAN card upload has flash glare over signature & DOB. Re-upload clear front copy.",
                    kycDocumentUri = "",
                    dipDocumentUri = "",
                    createdAtEpochMs = now - 7 * hour,
                    updatedAtEpochMs = now - 2 * hour
                ),
                CardApplicationEntity(
                    applicationId = "CP-2026-8408",
                    fullName = "Priya Iyer",
                    mobileNumber = "9819376501",
                    panNumber = "CMLPI2945R",
                    dateOfBirth = "03/11/1994",
                    city = "Mumbai",
                    pincode = "400051",
                    employmentType = EmploymentType.SALARIED.name,
                    companyName = "Nykaa E-Retail Ltd",
                    netMonthlyIncome = 86_500L,
                    existingCreditCard = true,
                    selectedCardTier = CardTier.TRAVEL.name,
                    addOnCardRequested = false,
                    addOnHolderName = "",
                    status = ApplicationStatus.KYC_PENDING.name,
                    fieldRemarks = "[21 Nov, 10:05 AM] Digital QDE completed; biometric video KYC link sent to customer",
                    dipReason = "",
                    kycDocumentUri = "",
                    dipDocumentUri = "",
                    createdAtEpochMs = now - 4 * hour,
                    updatedAtEpochMs = now - 3 * hour
                ),
                CardApplicationEntity(
                    applicationId = "CP-2026-8402",
                    fullName = "Arjun Malhotra",
                    mobileNumber = "9930184420",
                    panNumber = "DFSPM6104H",
                    dateOfBirth = "19/05/1996",
                    city = "Pune",
                    pincode = "411045",
                    employmentType = EmploymentType.SALARIED.name,
                    companyName = "Infosys Limited",
                    netMonthlyIncome = 62_000L,
                    existingCreditCard = false,
                    selectedCardTier = CardTier.CASHBACK.name,
                    addOnCardRequested = true,
                    addOnHolderName = "Meera Malhotra",
                    status = ApplicationStatus.DIP_HOLD.name,
                    fieldRemarks = "[20 Nov, 04:30 PM] QDE completed at Hinjewadi IT Park kiosk\n[21 Nov, 09:10 AM] DIP Hold: Latest October payslip missing employer seal",
                    dipReason = "Latest 2-month payslip mismatch with employer domain. Re-upload clear salary slip.",
                    kycDocumentUri = "",
                    dipDocumentUri = "",
                    createdAtEpochMs = now - 19 * hour,
                    updatedAtEpochMs = now - 4 * hour
                ),
                CardApplicationEntity(
                    applicationId = "CP-2026-8397",
                    fullName = "Sneha Deshpande",
                    mobileNumber = "9769553218",
                    panNumber = "EQRPD9182C",
                    dateOfBirth = "11/07/1990",
                    city = "Mumbai",
                    pincode = "400058",
                    employmentType = EmploymentType.SALARIED.name,
                    companyName = "Larsen & Toubro Infotech",
                    netMonthlyIncome = 135_000L,
                    existingCreditCard = true,
                    selectedCardTier = CardTier.PREMIUM.name,
                    addOnCardRequested = false,
                    addOnHolderName = "",
                    status = ApplicationStatus.APPROVED.name,
                    fieldRemarks = "[20 Nov, 02:15 PM] Corporate tie-up lead verified\n[20 Nov, 06:10 PM] Approved with ₹6,50,000 instant virtual card limit",
                    dipReason = "",
                    kycDocumentUri = "",
                    dipDocumentUri = "",
                    createdAtEpochMs = now - 24 * hour,
                    updatedAtEpochMs = now - 6 * hour
                ),
                CardApplicationEntity(
                    applicationId = "CP-2026-8391",
                    fullName = "Karthik Subramanian",
                    mobileNumber = "9820771450",
                    panNumber = "BHKPS3310T",
                    dateOfBirth = "30/09/1993",
                    city = "Bengaluru",
                    pincode = "560103",
                    employmentType = EmploymentType.SALARIED.name,
                    companyName = "Wipro Technologies",
                    netMonthlyIncome = 54_000L,
                    existingCreditCard = false,
                    selectedCardTier = CardTier.CASHBACK.name,
                    addOnCardRequested = false,
                    addOnHolderName = "",
                    status = ApplicationStatus.QDE_DONE.name,
                    fieldRemarks = "[21 Nov, 11:30 AM] Quick Data Entry captured during corporate desk visit",
                    dipReason = "",
                    kycDocumentUri = "",
                    dipDocumentUri = "",
                    createdAtEpochMs = now - 2 * hour,
                    updatedAtEpochMs = now - 2 * hour
                ),
                CardApplicationEntity(
                    applicationId = "CP-2026-8385",
                    fullName = "Farhan Siddiqui",
                    mobileNumber = "9833609127",
                    panNumber = "JKLPS5529A",
                    dateOfBirth = "08/12/1985",
                    city = "Mumbai",
                    pincode = "400064",
                    employmentType = EmploymentType.SELF_EMPLOYED.name,
                    companyName = "Siddiqui Logistics & Freight",
                    netMonthlyIncome = 38_000L,
                    existingCreditCard = false,
                    selectedCardTier = CardTier.BASIC.name,
                    addOnCardRequested = false,
                    addOnHolderName = "",
                    status = ApplicationStatus.DECLINED.name,
                    fieldRemarks = "[19 Nov, 03:20 PM] Application submitted\n[20 Nov, 11:05 AM] Declined by bureau policy: High unsecured utilization ratio",
                    dipReason = "",
                    kycDocumentUri = "",
                    dipDocumentUri = "",
                    createdAtEpochMs = now - 42 * hour,
                    updatedAtEpochMs = now - 16 * hour
                ),
                CardApplicationEntity(
                    applicationId = "CP-2026-8379",
                    fullName = "Meenakshi Reddy",
                    mobileNumber = "9849023176",
                    panNumber = "MNOPR8842E",
                    dateOfBirth = "22/04/1992",
                    city = "Hyderabad",
                    pincode = "500081",
                    employmentType = EmploymentType.SALARIED.name,
                    companyName = "Deloitte India",
                    netMonthlyIncome = 96_000L,
                    existingCreditCard = true,
                    selectedCardTier = CardTier.TRAVEL.name,
                    addOnCardRequested = true,
                    addOnHolderName = "Pranav Reddy",
                    status = ApplicationStatus.APPROVED.name,
                    fieldRemarks = "[19 Nov, 01:10 PM] Instant bureau match & Aadhaar e-KYC verified\n[19 Nov, 05:45 PM] Approved — Welcome kit dispatched",
                    dipReason = "",
                    kycDocumentUri = "",
                    dipDocumentUri = "",
                    createdAtEpochMs = now - 48 * hour,
                    updatedAtEpochMs = now - 28 * hour
                )
            )
        }
    }
}
