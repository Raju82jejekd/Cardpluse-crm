package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.CardApplicationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CardApplicationDao {

    @Query("SELECT * FROM card_applications ORDER BY updatedAtEpochMs DESC")
    fun getAllApplications(): Flow<List<CardApplicationEntity>>

    @Query("SELECT * FROM card_applications WHERE applicationId = :applicationId LIMIT 1")
    suspend fun getById(applicationId: String): CardApplicationEntity?

    @Query("SELECT COUNT(*) FROM card_applications")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(application: CardApplicationEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(applications: List<CardApplicationEntity>)

    @Query(
        """
        UPDATE card_applications
        SET status = :status,
            fieldRemarks = :remarks,
            dipReason = :dipReason,
            dipDocumentUri = :dipDocumentUri,
            updatedAtEpochMs = :updatedAt
        WHERE applicationId = :applicationId
        """
    )
    suspend fun updateApplicationProgress(
        applicationId: String,
        status: String,
        remarks: String,
        dipReason: String,
        dipDocumentUri: String,
        updatedAt: Long
    )
}
