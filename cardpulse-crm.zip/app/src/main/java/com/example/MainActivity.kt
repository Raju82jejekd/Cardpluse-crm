package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.FactCheck
import androidx.compose.material.icons.outlined.ViewList
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.FactCheck
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.ai.PlaceholderDocumentScanRepository
import com.example.data.local.AppDatabase
import com.example.data.repository.ApplicationRepository
import com.example.ui.screens.ApplicationDetailSheet
import com.example.ui.screens.ApplicationWizardScreen
import com.example.ui.screens.CrmMainContent
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CardPulseTheme
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.viewmodel.CrmTab
import com.example.ui.viewmodel.CrmViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val repository = ApplicationRepository(database.cardApplicationDao())
        val documentScanRepository = PlaceholderDocumentScanRepository()
        val viewModelFactory = CrmViewModel.Factory(repository, documentScanRepository)

        setContent {
            CardPulseTheme {
                val crmViewModel: CrmViewModel = viewModel(factory = viewModelFactory)
                CardPulseApp(viewModel = crmViewModel)
            }
        }
    }
}

@Composable
private fun CardPulseApp(viewModel: CrmViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val wizardState by viewModel.wizardState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.bannerMessage) {
        val message = uiState.bannerMessage
        if (!message.isNullOrBlank()) {
            snackbarHostState.showSnackbar(message)
            viewModel.clearBannerMessage()
        }
    }

    if (uiState.isWizardOpen) {
        ApplicationWizardScreen(
            wizardState = wizardState,
            viewModel = viewModel,
            onClose = viewModel::closeWizard
        )
        return
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 680.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = viewModel::openNewApplicationWizard,
                    modifier = Modifier.testTag("fab_new_lead"),
                    containerColor = RoyalBlue,
                    contentColor = PureWhite,
                    icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                    text = { Text("New Lead", fontWeight = FontWeight.Bold) }
                )
            },
            bottomBar = {
                if (!useNavigationRail) {
                    CrmBottomNavigationBar(
                        activeTab = uiState.activeTab,
                        dipHoldCount = uiState.kpi.dipHoldCount,
                        onTabSelected = viewModel::onTabSelected
                    )
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    CrmNavigationRail(
                        activeTab = uiState.activeTab,
                        dipHoldCount = uiState.kpi.dipHoldCount,
                        onTabSelected = viewModel::onTabSelected
                    )
                }

                Box(modifier = Modifier.weight(1f)) {
                    CrmMainContent(
                        uiState = uiState,
                        onNewApplicationClick = viewModel::openNewApplicationWizard,
                        onSearchQueryChange = viewModel::onSearchQueryChanged,
                        onStatusFilterSelected = viewModel::onStatusFilterSelected,
                        onKpiClick = viewModel::filterByKpi,
                        onApplicationClick = viewModel::openApplicationDetail,
                        onOpenDipQueue = { viewModel.onTabSelected(CrmTab.DIP_QUEUE) }
                    )
                }
            }
        }
    }

    val selectedApplication = uiState.selectedApplication
    if (selectedApplication != null) {
        ApplicationDetailSheet(
            application = selectedApplication,
            onDismiss = viewModel::closeApplicationDetail,
            onUpdateStatus = { newStatus ->
                viewModel.updateApplicationStatus(selectedApplication.applicationId, newStatus)
            },
            onAddRemark = { remark ->
                viewModel.addFieldRemark(selectedApplication.applicationId, remark)
            },
            onResolveDipHold = { docUri, note ->
                viewModel.resolveDipHold(selectedApplication.applicationId, docUri, note)
            }
        )
    }
}

@Composable
private fun CrmBottomNavigationBar(
    activeTab: CrmTab,
    dipHoldCount: Int,
    onTabSelected: (CrmTab) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        NavigationBarItem(
            selected = activeTab == CrmTab.DASHBOARD,
            onClick = { onTabSelected(CrmTab.DASHBOARD) },
            modifier = Modifier.testTag("nav_tab_dashboard"),
            icon = {
                Icon(
                    imageVector = if (activeTab == CrmTab.DASHBOARD) {
                        Icons.Rounded.Dashboard
                    } else {
                        Icons.Outlined.Dashboard
                    },
                    contentDescription = "Dashboard"
                )
            },
            label = { Text("Dashboard") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = RoyalBlue,
                selectedTextColor = RoyalBlue,
                indicatorColor = RoyalBlueContainer
            )
        )
        NavigationBarItem(
            selected = activeTab == CrmTab.PIPELINE,
            onClick = { onTabSelected(CrmTab.PIPELINE) },
            modifier = Modifier.testTag("nav_tab_pipeline"),
            icon = {
                Icon(
                    imageVector = if (activeTab == CrmTab.PIPELINE) {
                        Icons.Rounded.ViewList
                    } else {
                        Icons.Outlined.ViewList
                    },
                    contentDescription = "Pipeline"
                )
            },
            label = { Text("Pipeline") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = RoyalBlue,
                selectedTextColor = RoyalBlue,
                indicatorColor = RoyalBlueContainer
            )
        )
        NavigationBarItem(
            selected = activeTab == CrmTab.DIP_QUEUE,
            onClick = { onTabSelected(CrmTab.DIP_QUEUE) },
            modifier = Modifier.testTag("nav_tab_dip_queue"),
            icon = {
                BadgedBox(
                    badge = {
                        if (dipHoldCount > 0) {
                            Badge(
                                containerColor = AmberWarning,
                                contentColor = PureWhite
                            ) {
                                Text(dipHoldCount.toString())
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (activeTab == CrmTab.DIP_QUEUE) {
                            Icons.Rounded.FactCheck
                        } else {
                            Icons.Outlined.FactCheck
                        },
                        contentDescription = "DIP Hold Queue"
                    )
                }
            },
            label = { Text("DIP Hold") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = RoyalBlue,
                selectedTextColor = RoyalBlue,
                indicatorColor = RoyalBlueContainer
            )
        )
    }
}

@Composable
private fun CrmNavigationRail(
    activeTab: CrmTab,
    dipHoldCount: Int,
    onTabSelected: (CrmTab) -> Unit
) {
    NavigationRail(
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        NavigationRailItem(
            selected = activeTab == CrmTab.DASHBOARD,
            onClick = { onTabSelected(CrmTab.DASHBOARD) },
            icon = {
                Icon(
                    imageVector = if (activeTab == CrmTab.DASHBOARD) Icons.Rounded.Dashboard else Icons.Outlined.Dashboard,
                    contentDescription = "Dashboard"
                )
            },
            label = { Text("Dashboard") }
        )
        NavigationRailItem(
            selected = activeTab == CrmTab.PIPELINE,
            onClick = { onTabSelected(CrmTab.PIPELINE) },
            icon = {
                Icon(
                    imageVector = if (activeTab == CrmTab.PIPELINE) Icons.Rounded.ViewList else Icons.Outlined.ViewList,
                    contentDescription = "Pipeline"
                )
            },
            label = { Text("Pipeline") }
        )
        NavigationRailItem(
            selected = activeTab == CrmTab.DIP_QUEUE,
            onClick = { onTabSelected(CrmTab.DIP_QUEUE) },
            icon = {
                BadgedBox(
                    badge = {
                        if (dipHoldCount > 0) {
                            Badge(containerColor = AmberWarning, contentColor = PureWhite) {
                                Text(dipHoldCount.toString())
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (activeTab == CrmTab.DIP_QUEUE) Icons.Rounded.FactCheck else Icons.Outlined.FactCheck,
                        contentDescription = "DIP Hold"
                    )
                }
            },
            label = { Text("DIP Hold") }
        )
    }
}
