package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ai.DocumentScanRepository
import com.example.data.ai.DocumentScanResult
import com.example.data.model.ApplicationStatus
import com.example.data.model.CardApplicationEntity
import com.example.data.model.CardTier
import com.example.data.model.EmploymentType
import com.example.data.model.SalesExecutiveProfile
import com.example.data.repository.ApplicationRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class CrmTab {
    DASHBOARD,
    PIPELINE,
    DIP_QUEUE
}

data class KpiMetrics(
    val totalLeads: Int = 0,
    val inProgress: Int = 0,
    val approved: Int = 0,
    val rejected: Int = 0,
    val dipHoldCount: Int = 0
)

data class CrmUiState(
    val profile: SalesExecutiveProfile = SalesExecutiveProfile(),
    val allApplications: List<CardApplicationEntity> = emptyList(),
    val filteredApplications: List<CardApplicationEntity> = emptyList(),
    val dipHoldApplications: List<CardApplicationEntity> = emptyList(),
    val kpi: KpiMetrics = KpiMetrics(),
    val searchQuery: String = "",
    val selectedStatusFilter: ApplicationStatus? = null,
    val activeTab: CrmTab = CrmTab.DASHBOARD,
    val selectedApplicationId: String? = null,
    val isWizardOpen: Boolean = false,
    val bannerMessage: String? = null
) {
    val selectedApplication: CardApplicationEntity?
        get() = selectedApplicationId?.let { id ->
            allApplications.firstOrNull { it.applicationId == id }
        }
}

sealed interface ScanUiState {
    data object Idle : ScanUiState
    data object Scanning : ScanUiState
    data class Completed(val notice: String, val isSamplePlaceholder: Boolean) : ScanUiState
    data class Error(val message: String) : ScanUiState
}

data class WizardUiState(
    val currentStep: Int = 0,
    // Step 1: Customer & KYC
    val fullName: String = "",
    val mobileNumber: String = "",
    val panNumber: String = "",
    val dateOfBirth: String = "",
    val city: String = "",
    val pincode: String = "",
    val kycDocumentUri: String = "",
    val scanState: ScanUiState = ScanUiState.Idle,
    // Step 2: Employment & Eligibility
    val employmentType: EmploymentType = EmploymentType.SALARIED,
    val companyName: String = "",
    val netMonthlyIncomeInput: String = "",
    val existingCreditCard: Boolean = false,
    // Step 3: Card Recommendation & Add-on
    val selectedCardTier: CardTier = CardTier.BASIC,
    val userManuallyPickedTier: Boolean = false,
    val addOnCardRequested: Boolean = false,
    val addOnHolderName: String = "",
    // Step 4: Review & Submit
    val declarationAccepted: Boolean = false,
    val validationErrors: Map<String, String> = emptyMap(),
    val generatedApplicationId: String? = null
) {
    val parsedIncome: Long
        get() = netMonthlyIncomeInput.filter { it.isDigit() }.toLongOrNull() ?: 0L

    val recommendedTier: CardTier
        get() = CardTier.recommendedForIncome(parsedIncome, existingCreditCard)

    val eligibleTiers: List<CardTier>
        get() = CardTier.eligibleTiers(parsedIncome, existingCreditCard)
}

class CrmViewModel(
    private val repository: ApplicationRepository,
    private val documentScanRepository: DocumentScanRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _statusFilter = MutableStateFlow<ApplicationStatus?>(null)
    private val _activeTab = MutableStateFlow(CrmTab.DASHBOARD)
    private val _selectedApplicationId = MutableStateFlow<String?>(null)
    private val _isWizardOpen = MutableStateFlow(false)
    private val _bannerMessage = MutableStateFlow<String?>(null)

    private val _wizardState = MutableStateFlow(WizardUiState())
    val wizardState: StateFlow<WizardUiState> = _wizardState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureSeedData()
        }
    }

    val uiState: StateFlow<CrmUiState> = combine(
        repository.allApplications,
        _searchQuery,
        _statusFilter,
        _activeTab,
        combine(_selectedApplicationId, _isWizardOpen, _bannerMessage) { sel, wiz, msg ->
            Triple(sel, wiz, msg)
        }
    ) { apps, query, filter, tab, extras ->
        val normalizedQuery = query.trim().lowercase()
        val filtered = apps.filter { app ->
            val matchesFilter = filter == null || app.statusEnum == filter
            val matchesQuery = normalizedQuery.isEmpty() ||
                app.fullName.lowercase().contains(normalizedQuery) ||
                app.mobileNumber.contains(normalizedQuery) ||
                app.panNumber.lowercase().contains(normalizedQuery) ||
                app.applicationId.lowercase().contains(normalizedQuery) ||
                app.city.lowercase().contains(normalizedQuery)
            matchesFilter && matchesQuery
        }

        val dipHolds = apps.filter { it.statusEnum == ApplicationStatus.DIP_HOLD }
        val kpi = KpiMetrics(
            totalLeads = apps.size,
            inProgress = apps.count { it.statusEnum.isInProgress },
            approved = apps.count { it.statusEnum == ApplicationStatus.APPROVED },
            rejected = apps.count { it.statusEnum == ApplicationStatus.DECLINED },
            dipHoldCount = dipHolds.size
        )

        CrmUiState(
            allApplications = apps,
            filteredApplications = filtered,
            dipHoldApplications = dipHolds,
            kpi = kpi,
            searchQuery = query,
            selectedStatusFilter = filter,
            activeTab = tab,
            selectedApplicationId = extras.first,
            isWizardOpen = extras.second,
            bannerMessage = extras.third
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = CrmUiState()
    )

    fun onTabSelected(tab: CrmTab) {
        _activeTab.value = tab
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onStatusFilterSelected(status: ApplicationStatus?) {
        _statusFilter.value = if (_statusFilter.value == status) null else status
    }

    fun filterByKpi(status: ApplicationStatus?) {
        _statusFilter.value = status
        _activeTab.value = CrmTab.PIPELINE
    }

    fun openApplicationDetail(applicationId: String) {
        _selectedApplicationId.value = applicationId
    }

    fun closeApplicationDetail() {
        _selectedApplicationId.value = null
    }

    fun clearBannerMessage() {
        _bannerMessage.value = null
    }

    // --- Application Detail & DIP Rectification ---

    fun updateApplicationStatus(applicationId: String, newStatus: ApplicationStatus) {
        viewModelScope.launch {
            repository.updateStatus(applicationId, newStatus)
            _bannerMessage.value = "Updated $applicationId to ${newStatus.label}"
        }
    }

    fun addFieldRemark(applicationId: String, remark: String) {
        if (remark.isBlank()) return
        viewModelScope.launch {
            repository.addFieldRemark(applicationId, remark)
            _bannerMessage.value = "Field verification remark logged"
        }
    }

    fun resolveDipHold(applicationId: String, documentUri: String, resolutionNote: String) {
        viewModelScope.launch {
            repository.resolveDipHold(applicationId, documentUri, resolutionNote)
            _bannerMessage.value = "DIP Hold resolved — moved to KYC Pending"
        }
    }

    // --- 4-Step Application Wizard ---

    fun openNewApplicationWizard() {
        _wizardState.value = WizardUiState()
        _isWizardOpen.value = true
    }

    fun closeWizard() {
        _isWizardOpen.value = false
    }

    fun updateFullName(value: String) {
        _wizardState.update {
            it.copy(fullName = value, validationErrors = it.validationErrors - "fullName")
        }
    }

    fun updateMobileNumber(value: String) {
        val digits = value.filter { it.isDigit() }.take(10)
        _wizardState.update {
            it.copy(mobileNumber = digits, validationErrors = it.validationErrors - "mobileNumber")
        }
    }

    fun updatePanNumber(value: String) {
        val sanitized = value.filter { it.isLetterOrDigit() }.uppercase().take(10)
        _wizardState.update {
            it.copy(panNumber = sanitized, validationErrors = it.validationErrors - "panNumber")
        }
    }

    fun updateDateOfBirth(value: String) {
        val cleaned = value.filter { it.isDigit() || it == '/' }.take(10)
        _wizardState.update {
            it.copy(dateOfBirth = cleaned, validationErrors = it.validationErrors - "dateOfBirth")
        }
    }

    fun updateCity(value: String) {
        _wizardState.update {
            it.copy(city = value, validationErrors = it.validationErrors - "city")
        }
    }

    fun updatePincode(value: String) {
        val digits = value.filter { it.isDigit() }.take(6)
        _wizardState.update {
            it.copy(pincode = digits, validationErrors = it.validationErrors - "pincode")
        }
    }

    fun scanPanDocumentImage(context: Context, uri: Uri?) {
        viewModelScope.launch {
            _wizardState.update {
                it.copy(
                    kycDocumentUri = uri?.toString().orEmpty(),
                    scanState = ScanUiState.Scanning
                )
            }
            try {
                val imageBytes = if (uri != null) {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    }
                } else {
                    null
                }
                when (val result = documentScanRepository.extractPanDetails(imageBytes)) {
                    is DocumentScanResult.Success -> {
                        _wizardState.update { state ->
                            state.copy(
                                fullName = result.fullName,
                                panNumber = result.panNumber.uppercase(),
                                dateOfBirth = result.dateOfBirth,
                                scanState = ScanUiState.Completed(
                                    notice = result.notice,
                                    isSamplePlaceholder = result.isSamplePlaceholder
                                ),
                                validationErrors = state.validationErrors - setOf(
                                    "fullName", "panNumber", "dateOfBirth"
                                )
                            )
                        }
                    }
                    is DocumentScanResult.Error -> {
                        _wizardState.update {
                            it.copy(scanState = ScanUiState.Error(result.message))
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _wizardState.update {
                    it.copy(
                        scanState = ScanUiState.Error(
                            e.localizedMessage ?: "Unable to read selected document image."
                        )
                    )
                }
            }
        }
    }

    fun updateEmploymentType(type: EmploymentType) {
        _wizardState.update { it.copy(employmentType = type) }
    }

    fun updateCompanyName(value: String) {
        _wizardState.update {
            it.copy(companyName = value, validationErrors = it.validationErrors - "companyName")
        }
    }

    fun updateMonthlyIncome(value: String) {
        val digits = value.filter { it.isDigit() }.take(8)
        _wizardState.update { state ->
            val updated = state.copy(
                netMonthlyIncomeInput = digits,
                validationErrors = state.validationErrors - "netMonthlyIncome"
            )
            if (!state.userManuallyPickedTier) {
                updated.copy(selectedCardTier = updated.recommendedTier)
            } else {
                updated
            }
        }
    }

    fun updateExistingCreditCard(hasExisting: Boolean) {
        _wizardState.update { state ->
            val updated = state.copy(existingCreditCard = hasExisting)
            if (!state.userManuallyPickedTier) {
                updated.copy(selectedCardTier = updated.recommendedTier)
            } else {
                updated
            }
        }
    }

    fun selectCardTier(tier: CardTier) {
        _wizardState.update {
            it.copy(selectedCardTier = tier, userManuallyPickedTier = true)
        }
    }

    fun toggleAddOnCard(enabled: Boolean) {
        _wizardState.update {
            it.copy(
                addOnCardRequested = enabled,
                addOnHolderName = if (enabled) it.addOnHolderName else "",
                validationErrors = it.validationErrors - "addOnHolderName"
            )
        }
    }

    fun updateAddOnHolderName(value: String) {
        _wizardState.update {
            it.copy(
                addOnHolderName = value,
                validationErrors = it.validationErrors - "addOnHolderName"
            )
        }
    }

    fun toggleDeclaration(accepted: Boolean) {
        _wizardState.update {
            it.copy(
                declarationAccepted = accepted,
                validationErrors = it.validationErrors - "declaration"
            )
        }
    }

    fun goToStep(step: Int) {
        if (step in 0..3) {
            _wizardState.update { it.copy(currentStep = step, validationErrors = emptyMap()) }
        }
    }

    fun previousWizardStep() {
        val current = _wizardState.value.currentStep
        if (current > 0) {
            _wizardState.update { it.copy(currentStep = current - 1, validationErrors = emptyMap()) }
        } else {
            closeWizard()
        }
    }

    fun nextWizardStep() {
        val state = _wizardState.value
        val errors = validateStep(state, state.currentStep)
        if (errors.isNotEmpty()) {
            _wizardState.update { it.copy(validationErrors = errors) }
            return
        }
        val nextStep = (state.currentStep + 1).coerceAtMost(3)
        _wizardState.update { current ->
            val autoTier = if (nextStep == 2 && !current.userManuallyPickedTier) {
                current.recommendedTier
            } else {
                current.selectedCardTier
            }
            current.copy(
                currentStep = nextStep,
                selectedCardTier = autoTier,
                validationErrors = emptyMap()
            )
        }
    }

    fun submitApplication() {
        val state = _wizardState.value
        val errors = validateStep(state, 3)
        if (errors.isNotEmpty()) {
            _wizardState.update { it.copy(validationErrors = errors) }
            return
        }

        val generatedId = ApplicationRepository.generateApplicationId()
        val now = System.currentTimeMillis()
        val timestamp = ApplicationRepository.formatTimestamp(now)
        val initialStatus = if (state.kycDocumentUri.isNotBlank()) {
            ApplicationStatus.QDE_DONE
        } else {
            ApplicationStatus.KYC_PENDING
        }

        val entity = CardApplicationEntity(
            applicationId = generatedId,
            fullName = state.fullName.trim(),
            mobileNumber = state.mobileNumber.trim(),
            panNumber = state.panNumber.trim().uppercase(),
            dateOfBirth = state.dateOfBirth.trim(),
            city = state.city.trim(),
            pincode = state.pincode.trim(),
            employmentType = state.employmentType.name,
            companyName = state.companyName.trim(),
            netMonthlyIncome = state.parsedIncome,
            existingCreditCard = state.existingCreditCard,
            selectedCardTier = state.selectedCardTier.name,
            addOnCardRequested = state.addOnCardRequested,
            addOnHolderName = if (state.addOnCardRequested) state.addOnHolderName.trim() else "",
            status = initialStatus.name,
            fieldRemarks = "[$timestamp] Application originated by ${uiState.value.profile.name} (${uiState.value.profile.employeeCode}) — ${initialStatus.label}",
            dipReason = "",
            kycDocumentUri = state.kycDocumentUri,
            dipDocumentUri = "",
            createdAtEpochMs = now,
            updatedAtEpochMs = now
        )

        viewModelScope.launch {
            repository.createApplication(entity)
            _wizardState.update { it.copy(generatedApplicationId = generatedId) }
            _bannerMessage.value = "Application $generatedId created successfully"
        }
    }

    fun finishWizardAndOpenPipeline() {
        _isWizardOpen.value = false
        _activeTab.value = CrmTab.PIPELINE
        _wizardState.value = WizardUiState()
    }

    private fun validateStep(state: WizardUiState, step: Int): Map<String, String> {
        val errors = mutableMapOf<String, String>()
        when (step) {
            0 -> {
                if (state.fullName.trim().length < 3) {
                    errors["fullName"] = "Enter customer's full name (min 3 characters)"
                }
                if (!ApplicationRepository.isValidMobile(state.mobileNumber)) {
                    errors["mobileNumber"] = "Enter a valid 10-digit Indian mobile number"
                }
                if (!ApplicationRepository.isValidPan(state.panNumber)) {
                    errors["panNumber"] = "Invalid PAN format — expected like ABCDE1234F"
                }
                if (!ApplicationRepository.isValidDob(state.dateOfBirth)) {
                    errors["dateOfBirth"] = "Use DD/MM/YYYY format (e.g., 15/08/1992)"
                }
                if (state.city.trim().length < 2) {
                    errors["city"] = "Enter customer's city"
                }
                if (!ApplicationRepository.isValidPincode(state.pincode)) {
                    errors["pincode"] = "Enter valid 6-digit Indian pincode"
                }
            }
            1 -> {
                if (state.companyName.trim().length < 2) {
                    errors["companyName"] = if (state.employmentType == EmploymentType.SALARIED) {
                        "Enter employer / company name"
                    } else {
                        "Enter business / firm name"
                    }
                }
                if (state.parsedIncome < 15_000L) {
                    errors["netMonthlyIncome"] = "Minimum net monthly income is ₹15,000"
                }
            }
            2 -> {
                if (state.addOnCardRequested && state.addOnHolderName.trim().length < 3) {
                    errors["addOnHolderName"] = "Enter family member / nominee full name"
                }
            }
            3 -> {
                if (!state.declarationAccepted) {
                    errors["declaration"] = "Please confirm digital customer declaration before submitting"
                }
            }
        }
        return errors
    }

    class Factory(
        private val repository: ApplicationRepository,
        private val documentScanRepository: DocumentScanRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return CrmViewModel(repository, documentScanRepository) as T
        }
    }
}
