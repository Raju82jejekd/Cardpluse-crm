package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Business
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DocumentScanner
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PersonAddAlt1
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CardTier
import com.example.data.model.EmploymentType
import com.example.data.model.formatIndianRupees
import com.example.data.repository.ApplicationRepository
import com.example.ui.components.CardTierVisualMini
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberOnContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.EmeraldOnContainer
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.theme.RoyalBlueSurfaceTint
import com.example.ui.viewmodel.CrmViewModel
import com.example.ui.viewmodel.ScanUiState
import com.example.ui.viewmodel.WizardUiState
import java.util.Calendar
import java.util.Locale

private val WizardStepLabels = listOf("KYC", "Income", "Card", "Review")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApplicationWizardScreen(
    wizardState: WizardUiState,
    viewModel: CrmViewModel,
    onClose: () -> Unit
) {
    BackHandler {
        viewModel.previousWizardStep()
    }

    if (wizardState.generatedApplicationId != null) {
        ApplicationSubmittedDialog(
            applicationId = wizardState.generatedApplicationId,
            customerName = wizardState.fullName,
            cardTier = wizardState.selectedCardTier,
            onViewPipeline = viewModel::finishWizardAndOpenPipeline,
            onStartAnother = viewModel::openNewApplicationWizard
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "New Credit Card Application",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Step ${wizardState.currentStep + 1} of 4 — ${
                                when (wizardState.currentStep) {
                                    0 -> "Customer & KYC Details"
                                    1 -> "Employment & Eligibility"
                                    2 -> "Card Recommendation & Add-on"
                                    else -> "Review & Submit"
                                }
                            }",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = viewModel::previousWizardStep,
                        modifier = Modifier.testTag("wizard_back_button")
                    ) {
                        Icon(
                            imageVector = if (wizardState.currentStep == 0) {
                                Icons.Rounded.Close
                            } else {
                                Icons.AutoMirrored.Rounded.ArrowBack
                            },
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 6.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = viewModel::previousWizardStep,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("wizard_prev_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (wizardState.currentStep == 0) "Cancel" else "Previous")
                    }

                    Button(
                        onClick = {
                            if (wizardState.currentStep < 3) {
                                viewModel.nextWizardStep()
                            } else {
                                viewModel.submitApplication()
                            }
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp)
                            .testTag(
                                if (wizardState.currentStep < 3) "wizard_next_button"
                                else "generate_application_id_button"
                            ),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (wizardState.currentStep == 3) EmeraldGreen else RoyalBlue,
                            contentColor = PureWhite
                        )
                    ) {
                        Text(
                            text = if (wizardState.currentStep < 3) "Continue" else "Generate Application ID",
                            fontWeight = FontWeight.Bold
                        )
                        if (wizardState.currentStep < 3) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp)
            ) {
                WizardStepIndicator(
                    currentStep = wizardState.currentStep,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    AnimatedContent(
                        targetState = wizardState.currentStep,
                        label = "wizard_step_transition"
                    ) { step ->
                        when (step) {
                            0 -> StepOneKycSection(wizardState, viewModel)
                            1 -> StepTwoEmploymentSection(wizardState, viewModel)
                            2 -> StepThreeCardTierSection(wizardState, viewModel)
                            else -> StepFourReviewSection(wizardState, viewModel)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun WizardStepIndicator(
    currentStep: Int,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        WizardStepLabels.forEachIndexed { index, label ->
            val isCompleted = index < currentStep
            val isCurrent = index == currentStep
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(if (index < WizardStepLabels.lastIndex) 1f else 0.7f)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isCompleted -> EmeraldGreen
                                    isCurrent -> RoyalBlue
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(
                                imageVector = Icons.Rounded.Check,
                                contentDescription = "Completed",
                                tint = PureWhite,
                                modifier = Modifier.size(16.dp)
                            )
                        } else {
                            Text(
                                text = "${index + 1}",
                                fontFamily = JetBrainsMono,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent) PureWhite else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                        color = if (isCurrent) RoyalBlue else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (index < WizardStepLabels.lastIndex) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp)
                            .padding(bottom = 16.dp)
                            .height(2.dp)
                            .background(
                                if (isCompleted) EmeraldGreen else MaterialTheme.colorScheme.outlineVariant
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun StepOneKycSection(
    state: WizardUiState,
    viewModel: CrmViewModel
) {
    val context = LocalContext.current
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.scanPanDocumentImage(context, uri)
        }
    }

    val openDobPicker = {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val formatted = String.format(
                    Locale.ENGLISH,
                    "%02d/%02d/%04d",
                    dayOfMonth,
                    month + 1,
                    year
                )
                viewModel.updateDateOfBirth(formatted)
            },
            cal.get(Calendar.YEAR) - 28,
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // AI Smart Document Scan Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = RoyalBlueSurfaceTint,
            border = BorderStroke(1.dp, RoyalBlue.copy(alpha = 0.25f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(RoyalBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DocumentScanner,
                            contentDescription = "Smart Document Scan",
                            tint = PureWhite,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "AI Smart Document Scan",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = RoyalBlue
                            )
                            Icon(
                                imageVector = Icons.Rounded.AutoAwesome,
                                contentDescription = null,
                                tint = EmeraldGreen,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = "Upload PAN / ID image to auto-fill Name, PAN & DOB",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (state.kycDocumentUri.isNotBlank()) {
                    AsyncImage(
                        model = state.kycDocumentUri,
                        contentDescription = "Uploaded PAN document preview",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        enabled = state.scanState !is ScanUiState.Scanning,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("upload_pan_image_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                    ) {
                        if (state.scanState is ScanUiState.Scanning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = PureWhite
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Scanning ID...")
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Badge,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Upload PAN / ID Image", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    OutlinedButton(
                        onClick = { viewModel.scanPanDocumentImage(context, null) },
                        enabled = state.scanState !is ScanUiState.Scanning,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("demo_pan_scan_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Sample Fill")
                    }
                }

                when (val scan = state.scanState) {
                    is ScanUiState.Completed -> {
                        Surface(
                            color = if (scan.isSamplePlaceholder) AmberContainer else EmeraldContainer,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Info,
                                    contentDescription = null,
                                    tint = if (scan.isSamplePlaceholder) AmberWarning else EmeraldGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = scan.notice,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (scan.isSamplePlaceholder) AmberOnContainer else EmeraldOnContainer
                                )
                            }
                        }
                    }
                    is ScanUiState.Error -> {
                        Text(
                            text = scan.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    else -> Unit
                }
            }
        }

        // KYC Form Fields
        OutlinedTextField(
            value = state.fullName,
            onValueChange = viewModel::updateFullName,
            label = { Text("Full Name (as per PAN)") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("wizard_full_name_input"),
            isError = state.validationErrors.containsKey("fullName"),
            supportingText = state.validationErrors["fullName"]?.let { err -> { Text(err) } },
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = state.mobileNumber,
            onValueChange = viewModel::updateMobileNumber,
            label = { Text("Mobile Number") },
            prefix = { Text("+91 ", fontFamily = JetBrainsMono) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("wizard_mobile_input"),
            isError = state.validationErrors.containsKey("mobileNumber"),
            supportingText = state.validationErrors["mobileNumber"]?.let { err -> { Text(err) } },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        val panValid = ApplicationRepository.isValidPan(state.panNumber)
        OutlinedTextField(
            value = state.panNumber,
            onValueChange = viewModel::updatePanNumber,
            label = { Text("PAN Number (e.g., ABCDE1234F)") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("wizard_pan_input"),
            textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = JetBrainsMono),
            isError = state.validationErrors.containsKey("panNumber"),
            trailingIcon = {
                if (panValid) {
                    Icon(
                        imageVector = Icons.Rounded.Verified,
                        contentDescription = "Valid PAN format",
                        tint = EmeraldGreen
                    )
                }
            },
            supportingText = {
                val err = state.validationErrors["panNumber"]
                if (err != null) {
                    Text(err)
                } else if (panValid) {
                    Text("Valid PAN format verified", color = EmeraldGreen)
                } else {
                    Text("5 letters + 4 digits + 1 letter")
                }
            },
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        OutlinedTextField(
            value = state.dateOfBirth,
            onValueChange = viewModel::updateDateOfBirth,
            label = { Text("Date of Birth (DD/MM/YYYY)") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("wizard_dob_input"),
            textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = JetBrainsMono),
            trailingIcon = {
                IconButton(onClick = openDobPicker) {
                    Icon(
                        imageVector = Icons.Rounded.CalendarMonth,
                        contentDescription = "Select Date of Birth",
                        tint = RoyalBlue
                    )
                }
            },
            isError = state.validationErrors.containsKey("dateOfBirth"),
            supportingText = state.validationErrors["dateOfBirth"]?.let { err -> { Text(err) } },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = state.city,
                onValueChange = viewModel::updateCity,
                label = { Text("City") },
                modifier = Modifier
                    .weight(1.2f)
                    .testTag("wizard_city_input"),
                isError = state.validationErrors.containsKey("city"),
                supportingText = state.validationErrors["city"]?.let { err -> { Text(err) } },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = state.pincode,
                onValueChange = viewModel::updatePincode,
                label = { Text("Pincode") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("wizard_pincode_input"),
                textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = JetBrainsMono),
                isError = state.validationErrors.containsKey("pincode"),
                supportingText = state.validationErrors["pincode"]?.let { err -> { Text(err) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun StepTwoEmploymentSection(
    state: WizardUiState,
    viewModel: CrmViewModel
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "Employment Type",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                EmploymentType.entries.forEachIndexed { index, type ->
                    SegmentedButton(
                        selected = state.employmentType == type,
                        onClick = { viewModel.updateEmploymentType(type) },
                        shape = SegmentedButtonDefaults.itemShape(
                            index = index,
                            count = EmploymentType.entries.size
                        ),
                        modifier = Modifier.testTag("employment_type_${type.name.lowercase()}")
                    ) {
                        Text(type.label)
                    }
                }
            }
        }

        OutlinedTextField(
            value = state.companyName,
            onValueChange = viewModel::updateCompanyName,
            label = {
                Text(
                    if (state.employmentType == EmploymentType.SALARIED) {
                        "Company / Employer Name"
                    } else {
                        "Business / Firm Name"
                    }
                )
            },
            leadingIcon = {
                Icon(Icons.Rounded.Business, contentDescription = null)
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("wizard_company_input"),
            isError = state.validationErrors.containsKey("companyName"),
            supportingText = state.validationErrors["companyName"]?.let { err -> { Text(err) } },
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = state.netMonthlyIncomeInput,
                onValueChange = viewModel::updateMonthlyIncome,
                label = { Text("Net Monthly Income (INR)") },
                prefix = { Text("₹ ", fontFamily = JetBrainsMono, fontWeight = FontWeight.Bold) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("wizard_income_input"),
                textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = JetBrainsMono),
                isError = state.validationErrors.containsKey("netMonthlyIncome"),
                supportingText = state.validationErrors["netMonthlyIncome"]?.let { err ->
                    { Text(err) }
                } ?: {
                    if (state.parsedIncome > 0) {
                        Text(
                            text = "Eligible for up to ${state.recommendedTier.title} (${state.recommendedTier.tierLabel})",
                            color = EmeraldGreen,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Text("Used to compute eligible card tiers")
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(30_000L to "₹30K", 55_000L to "₹55K", 90_000L to "₹90K", 150_000L to "₹1.5L")
                    .forEach { (amount, label) ->
                        SuggestionChip(
                            onClick = { viewModel.updateMonthlyIncome(amount.toString()) },
                            label = { Text(label, fontFamily = JetBrainsMono) }
                        )
                    }
            }
        }

        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Existing Credit Card Holder?",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Existing cardholders with active bureau history receive a 10% eligibility boost.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = state.existingCreditCard,
                        onClick = { viewModel.updateExistingCreditCard(true) },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                        modifier = Modifier.testTag("existing_card_yes")
                    ) {
                        Text("Yes, Cardholder")
                    }
                    SegmentedButton(
                        selected = !state.existingCreditCard,
                        onClick = { viewModel.updateExistingCreditCard(false) },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        modifier = Modifier.testTag("existing_card_no")
                    ) {
                        Text("No, New to Card")
                    }
                }
            }
        }
    }
}

@Composable
private fun StepThreeCardTierSection(
    state: WizardUiState,
    viewModel: CrmViewModel
) {
    val recommended = state.recommendedTier
    val eligibleTiers = state.eligibleTiers

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Surface(
            color = EmeraldContainer,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.35f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Verified,
                    contentDescription = null,
                    tint = EmeraldGreen
                )
                Column {
                    Text(
                        text = "Recommended Tier: ${recommended.title}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldOnContainer
                    )
                    Text(
                        text = "Based on ${formatIndianRupees(state.parsedIncome)}/mo net income" +
                            if (state.existingCreditCard) " + existing card history" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = EmeraldOnContainer
                    )
                }
            }
        }

        CardTier.entries.forEach { tier ->
            val isEligible = tier in eligibleTiers
            val isSelected = state.selectedCardTier == tier
            val isRecommended = tier == recommended

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_tier_${tier.name.lowercase()}")
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(enabled = isEligible) { viewModel.selectCardTier(tier) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = when {
                        isSelected -> RoyalBlueSurfaceTint
                        isEligible -> MaterialTheme.colorScheme.surface
                        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                    }
                ),
                border = BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) RoyalBlue else MaterialTheme.colorScheme.outlineVariant
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CardTierVisualMini(tier = tier)

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = tier.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isEligible) {
                                    MaterialTheme.colorScheme.onSurface
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                            if (isRecommended) {
                                Surface(
                                    color = EmeraldGreen,
                                    shape = RoundedCornerShape(999.dp)
                                ) {
                                    Text(
                                        text = "BEST MATCH",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PureWhite,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = tier.highlight,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Text(
                            text = if (isEligible) {
                                "${tier.annualFeeLabel} • ${tier.creditLimitHint}"
                            } else {
                                "Requires min. ${formatIndianRupees(tier.minMonthlyIncome)}/mo income"
                            },
                            fontFamily = JetBrainsMono,
                            fontSize = 11.sp,
                            color = if (isEligible) RoyalBlue else MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        // Add-on Card Toggle Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PersonAddAlt1,
                            contentDescription = null,
                            tint = RoyalBlue
                        )
                        Column {
                            Text(
                                text = "Include Complimentary Add-on Card",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Issue a linked family card with shared limit",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = state.addOnCardRequested,
                        onCheckedChange = viewModel::toggleAddOnCard,
                        modifier = Modifier.testTag("addon_card_switch"),
                        colors = SwitchDefaults.colors(checkedTrackColor = RoyalBlue)
                    )
                }

                AnimatedVisibility(visible = state.addOnCardRequested) {
                    OutlinedTextField(
                        value = state.addOnHolderName,
                        onValueChange = viewModel::updateAddOnHolderName,
                        label = { Text("Nominee / Family Member Full Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("addon_holder_name_input"),
                        isError = state.validationErrors.containsKey("addOnHolderName"),
                        supportingText = state.validationErrors["addOnHolderName"]?.let { err ->
                            { Text(err) }
                        },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun StepFourReviewSection(
    state: WizardUiState,
    viewModel: CrmViewModel
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ReviewSummaryCard(
            title = "1. Customer & KYC Details",
            onEdit = { viewModel.goToStep(0) },
            rows = listOf(
                "Full Name" to state.fullName,
                "Mobile" to "+91 ${state.mobileNumber}",
                "PAN Number" to state.panNumber,
                "Date of Birth" to state.dateOfBirth,
                "City & Pincode" to "${state.city} - ${state.pincode}"
            )
        )

        ReviewSummaryCard(
            title = "2. Employment & Eligibility",
            onEdit = { viewModel.goToStep(1) },
            rows = listOf(
                "Employment" to state.employmentType.label,
                "Organization" to state.companyName,
                "Net Monthly Income" to formatIndianRupees(state.parsedIncome),
                "Existing Cardholder" to if (state.existingCreditCard) "Yes" else "No"
            )
        )

        ReviewSummaryCard(
            title = "3. Selected Credit Card",
            onEdit = { viewModel.goToStep(2) },
            rows = listOf(
                "Card Variant" to "${state.selectedCardTier.title} (${state.selectedCardTier.tierLabel})",
                "Annual Fee" to state.selectedCardTier.annualFeeLabel,
                "Add-on Card" to if (state.addOnCardRequested) {
                    "Yes — ${state.addOnHolderName}"
                } else {
                    "Not Requested"
                }
            )
        )

        Surface(
            shape = RoundedCornerShape(14.dp),
            color = if (state.validationErrors.containsKey("declaration")) {
                MaterialTheme.colorScheme.errorContainer
            } else {
                MaterialTheme.colorScheme.surface
            },
            border = BorderStroke(
                1.dp,
                if (state.validationErrors.containsKey("declaration")) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.outlineVariant
                }
            )
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    verticalAlignment = Alignment.Top,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.toggleDeclaration(!state.declarationAccepted) }
                ) {
                    Checkbox(
                        checked = state.declarationAccepted,
                        onCheckedChange = viewModel::toggleDeclaration,
                        modifier = Modifier.testTag("digital_declaration_checkbox"),
                        colors = CheckboxDefaults.colors(checkedColor = EmeraldGreen)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "I confirm the customer has provided informed digital consent for bureau credit checks, PAN/KYC verification, and credit card origination under RBI guidelines.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
                state.validationErrors["declaration"]?.let { err ->
                    Text(
                        text = err,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(start = 12.dp, top = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ReviewSummaryCard(
    title: String,
    onEdit: () -> Unit,
    rows: List<Pair<String, String>>
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = RoyalBlue
                )
                TextButton(onClick = onEdit) {
                    Icon(
                        imageVector = Icons.Rounded.Edit,
                        contentDescription = "Edit section",
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Edit")
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            rows.forEach { (label, value) ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = value,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
private fun ApplicationSubmittedDialog(
    applicationId: String,
    customerName: String,
    cardTier: CardTier,
    onViewPipeline: () -> Unit,
    onStartAnother: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onViewPipeline,
        icon = {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(EmeraldContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.CheckCircle,
                    contentDescription = "Submitted",
                    tint = EmeraldGreen,
                    modifier = Modifier.size(34.dp)
                )
            }
        },
        title = {
            Text(
                text = "Application ID Generated",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    color = RoyalBlueContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = applicationId,
                        fontFamily = JetBrainsMono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = RoyalBlue,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                    )
                }
                Text(
                    text = "$customerName • ${cardTier.title}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Saved locally to your pipeline. Track KYC, update remarks, or manage DIP rectification anytime.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onViewPipeline,
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text("View in Pipeline")
            }
        },
        dismissButton = {
            TextButton(onClick = onStartAnother) {
                Text("New Application")
            }
        }
    )
}
