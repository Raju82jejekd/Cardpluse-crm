package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CreditCard
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.ReportProblem
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApplicationStatus
import com.example.data.model.CardApplicationEntity
import com.example.data.model.CardTier
import com.example.data.model.formatIndianRupees
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberOnContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.CrimsonOnContainer
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanOnContainer
import com.example.ui.theme.CyanReview
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.EmeraldOnContainer
import com.example.ui.theme.IndigoContainer
import com.example.ui.theme.IndigoInfo
import com.example.ui.theme.IndigoOnContainer
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueDark
import com.example.ui.theme.RoyalBlueLight
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900

data class StatusVisuals(
    val containerColor: Color,
    val contentColor: Color,
    val accentColor: Color,
    val icon: ImageVector
)

fun ApplicationStatus.visuals(): StatusVisuals = when (this) {
    ApplicationStatus.QDE_DONE -> StatusVisuals(
        containerColor = IndigoContainer,
        contentColor = IndigoOnContainer,
        accentColor = IndigoInfo,
        icon = Icons.Rounded.TaskAlt
    )
    ApplicationStatus.KYC_PENDING -> StatusVisuals(
        containerColor = CyanContainer,
        contentColor = CyanOnContainer,
        accentColor = CyanReview,
        icon = Icons.Rounded.HourglassTop
    )
    ApplicationStatus.DIP_HOLD -> StatusVisuals(
        containerColor = AmberContainer,
        contentColor = AmberOnContainer,
        accentColor = AmberWarning,
        icon = Icons.Rounded.WarningAmber
    )
    ApplicationStatus.APPROVED -> StatusVisuals(
        containerColor = EmeraldContainer,
        contentColor = EmeraldOnContainer,
        accentColor = EmeraldGreen,
        icon = Icons.Rounded.CheckCircle
    )
    ApplicationStatus.DECLINED -> StatusVisuals(
        containerColor = CrimsonContainer,
        contentColor = CrimsonOnContainer,
        accentColor = CrimsonError,
        icon = Icons.Rounded.Cancel
    )
}

@Composable
fun StatusBadge(
    status: ApplicationStatus,
    modifier: Modifier = Modifier
) {
    val visuals = status.visuals()
    Surface(
        modifier = modifier,
        color = visuals.containerColor,
        contentColor = visuals.contentColor,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, visuals.accentColor.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                imageVector = visuals.icon,
                contentDescription = status.label,
                modifier = Modifier.size(13.dp),
                tint = visuals.accentColor
            )
            Text(
                text = status.label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = visuals.contentColor
            )
        }
    }
}

@Composable
fun KpiMetricCard(
    title: String,
    count: Int,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    iconBackground: Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(iconBackground),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Text(
                    text = count.toString(),
                    fontFamily = JetBrainsMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun ApplicationListCard(
    application: CardApplicationEntity,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val initials = application.fullName
        .split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercase() }
        .ifEmpty { "CU" }
    val status = application.statusEnum
    val tier = application.cardTierEnum

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("application_card_${application.applicationId}")
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (status == ApplicationStatus.DIP_HOLD) 1.5.dp else 1.dp,
            color = if (status == ApplicationStatus.DIP_HOLD) {
                AmberWarning.copy(alpha = 0.65f)
            } else {
                MaterialTheme.colorScheme.outlineVariant
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = initials,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = application.fullName,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        StatusBadge(status = status)
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = application.applicationId,
                            fontFamily = JetBrainsMono,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "•",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = application.panNumber,
                            fontFamily = JetBrainsMono,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CreditCard,
                                contentDescription = tier.title,
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${tier.tierLabel} • ${formatIndianRupees(application.netMonthlyIncome)}/mo",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                            contentDescription = "Open application details",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            if (status == ApplicationStatus.DIP_HOLD && application.dipReason.isNotBlank()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AmberContainer.copy(alpha = 0.7f))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ReportProblem,
                        contentDescription = "DIP Hold alert",
                        tint = AmberWarning,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "DIP Action Required: ${application.dipReason}",
                        style = MaterialTheme.typography.bodySmall,
                        color = AmberOnContainer,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun CardTierVisualMini(
    tier: CardTier,
    modifier: Modifier = Modifier
) {
    val gradient = when (tier) {
        CardTier.BASIC -> listOf(Slate700, Slate900)
        CardTier.CASHBACK -> listOf(RoyalBlueLight, RoyalBlue)
        CardTier.TRAVEL -> listOf(RoyalBlue, EmeraldGreen)
        CardTier.PREMIUM -> listOf(RoyalBlueDark, Color(0xFF1E1B4B), Color(0xFF064E3B))
    }

    Box(
        modifier = modifier
            .width(86.dp)
            .height(54.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.linearGradient(gradient))
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(width = 16.dp, height = 11.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0xFFFBBF24).copy(alpha = 0.9f))
                .align(Alignment.TopStart)
        )
        Text(
            text = tier.tierLabel.uppercase(),
            fontFamily = JetBrainsMono,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            color = PureWhite.copy(alpha = 0.92f),
            modifier = Modifier.align(Alignment.BottomStart)
        )
        Icon(
            imageVector = Icons.Rounded.CreditCard,
            contentDescription = null,
            tint = PureWhite.copy(alpha = 0.45f),
            modifier = Modifier
                .size(16.dp)
                .align(Alignment.TopEnd)
        )
    }
}
