package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.PendingActions
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.ApplicationStatus
import com.example.data.model.SalesExecutiveProfile
import com.example.ui.components.ApplicationListCard
import com.example.ui.components.KpiMetricCard
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberOnContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.EmeraldGreenBright
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.RoyalBlueContainer
import com.example.ui.theme.RoyalBlueDark
import com.example.ui.viewmodel.CrmTab
import com.example.ui.viewmodel.CrmUiState

@Composable
fun CrmMainContent(
    uiState: CrmUiState,
    onNewApplicationClick: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onStatusFilterSelected: (ApplicationStatus?) -> Unit,
    onKpiClick: (ApplicationStatus?) -> Unit,
    onApplicationClick: (String) -> Unit,
    onOpenDipQueue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val displayedList = when (uiState.activeTab) {
        CrmTab.DASHBOARD -> uiState.filteredApplications
        CrmTab.PIPELINE -> uiState.filteredApplications
        CrmTab.DIP_QUEUE -> uiState.dipHoldApplications.filter { app ->
            val q = uiState.searchQuery.trim().lowercase()
            q.isEmpty() ||
                app.fullName.lowercase().contains(q) ||
                app.mobileNumber.contains(q) ||
                app.applicationId.lowercase().contains(q) ||
                app.panNumber.lowercase().contains(q)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (uiState.activeTab == CrmTab.DASHBOARD) {
                item(key = "executive_header") {
                    ExecutiveHeaderCard(
                        profile = uiState.profile,
                        achievedCount = uiState.kpi.totalLeads,
                        approvedCount = uiState.kpi.approved
                    )
                }

                item(key = "primary_cta") {
                    Button(
                        onClick = onNewApplicationClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("new_lead_top_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RoyalBlue,
                            contentColor = PureWhite
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "New Lead / Credit Card Application",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                item(key = "kpi_grid") {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            KpiMetricCard(
                                title = "Total Leads",
                                count = uiState.kpi.totalLeads,
                                subtitle = "All active & closed",
                                icon = Icons.Rounded.Groups,
                                accentColor = RoyalBlue,
                                iconBackground = RoyalBlueContainer,
                                testTag = "kpi_total_leads",
                                onClick = { onKpiClick(null) },
                                modifier = Modifier.weight(1f)
                            )
                            KpiMetricCard(
                                title = "In-Progress",
                                count = uiState.kpi.inProgress,
                                subtitle = "QDE / KYC / DIP",
                                icon = Icons.Rounded.PendingActions,
                                accentColor = AmberWarning,
                                iconBackground = AmberContainer,
                                testTag = "kpi_in_progress",
                                onClick = { onKpiClick(ApplicationStatus.KYC_PENDING) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            KpiMetricCard(
                                title = "Approved",
                                count = uiState.kpi.approved,
                                subtitle = "Cards sanctioned",
                                icon = Icons.Rounded.CheckCircle,
                                accentColor = EmeraldGreen,
                                iconBackground = EmeraldContainer,
                                testTag = "kpi_approved",
                                onClick = { onKpiClick(ApplicationStatus.APPROVED) },
                                modifier = Modifier.weight(1f)
                            )
                            KpiMetricCard(
                                title = "Rejected",
                                count = uiState.kpi.rejected,
                                subtitle = "Bureau / policy",
                                icon = Icons.Rounded.Cancel,
                                accentColor = CrimsonError,
                                iconBackground = CrimsonContainer,
                                testTag = "kpi_rejected",
                                onClick = { onKpiClick(ApplicationStatus.DECLINED) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                if (uiState.kpi.dipHoldCount > 0) {
                    item(key = "dip_hold_alert") {
                        DipHoldAlertBanner(
                            dipCount = uiState.kpi.dipHoldCount,
                            onReviewClick = onOpenDipQueue
                        )
                    }
                }
            } else {
                item(key = "tab_header") {
                    SectionScreenHeader(
                        title = if (uiState.activeTab == CrmTab.PIPELINE) {
                            "Application Pipeline"
                        } else {
                            "DIP Hold Rectification Queue"
                        },
                        subtitle = if (uiState.activeTab == CrmTab.PIPELINE) {
                            "${uiState.filteredApplications.size} of ${uiState.allApplications.size} applications • Tap any case to update"
                        } else {
                            "${uiState.dipHoldApplications.size} cases awaiting document re-upload or clarification"
                        }
                    )
                }
            }

            item(key = "search_and_filter") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = uiState.searchQuery,
                        onValueChange = onSearchQueryChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_applications_input"),
                        placeholder = {
                            Text(
                                text = "Search customer, mobile, PAN or App ID...",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = "Search",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        trailingIcon = {
                            if (uiState.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchQueryChange("") }) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "Clear search"
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                            focusedBorderColor = RoyalBlue,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        )
                    )

                    if (uiState.activeTab != CrmTab.DIP_QUEUE) {
                        StatusFilterBar(
                            selectedStatus = uiState.selectedStatusFilter,
                            onSelectStatus = onStatusFilterSelected
                        )
                    }
                }
            }

            if (uiState.activeTab == CrmTab.DASHBOARD) {
                item(key = "recent_header") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (uiState.selectedStatusFilter == null && uiState.searchQuery.isBlank()) {
                                "Active Application Pipeline"
                            } else {
                                "Matching Applications (${displayedList.size})"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        if (uiState.selectedStatusFilter != null || uiState.searchQuery.isNotBlank()) {
                            TextButton(
                                onClick = {
                                    onSearchQueryChange("")
                                    onStatusFilterSelected(null)
                                }
                            ) {
                                Text("Reset filters")
                            }
                        }
                    }
                }
            }

            if (displayedList.isEmpty()) {
                item(key = "empty_state") {
                    EmptyApplicationsState(
                        isDipQueue = uiState.activeTab == CrmTab.DIP_QUEUE,
                        onStartNewLead = onNewApplicationClick
                    )
                }
            } else {
                items(
                    items = displayedList,
                    key = { it.applicationId }
                ) { app ->
                    ApplicationListCard(
                        application = app,
                        onClick = { onApplicationClick(app.applicationId) }
                    )
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(76.dp))
            }
        }
    }
}

@Composable
private fun ExecutiveHeaderCard(
    profile: SalesExecutiveProfile,
    achievedCount: Int,
    approvedCount: Int
) {
    val rawProgress = (achievedCount.toFloat() / profile.dailyTarget.coerceAtLeast(1)).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = rawProgress,
        animationSpec = tween(durationMillis = 550),
        label = "target_progress"
    )
    val percentage = (rawProgress * 100).toInt()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(RoyalBlueDark)
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_card_premium_bg_1795259577870),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize(),
            alpha = 0.85f
        )
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            RoyalBlueDark.copy(alpha = 0.82f),
                            RoyalBlue.copy(alpha = 0.55f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_exec_avatar_1795259637375),
                    contentDescription = "Sales Executive Profile Photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .border(2.dp, EmeraldGreenBright, CircleShape)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = profile.name,
                            style = MaterialTheme.typography.titleLarge,
                            color = PureWhite,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Surface(
                            color = EmeraldGreenBright.copy(alpha = 0.22f),
                            shape = RoundedCornerShape(999.dp)
                        ) {
                            Text(
                                text = profile.employeeCode,
                                fontFamily = JetBrainsMono,
                                fontSize = 10.sp,
                                color = Color(0xFFA7F3D0),
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = profile.role,
                        style = MaterialTheme.typography.bodySmall,
                        color = PureWhite.copy(alpha = 0.82f)
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.LocationOn,
                            contentDescription = "Territory",
                            tint = Color(0xFF93C5FD),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = profile.territoryName,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFDBEAFE),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Surface(
                color = PureWhite.copy(alpha = 0.12f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.16f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Daily Origination Target",
                            style = MaterialTheme.typography.labelMedium,
                            color = PureWhite.copy(alpha = 0.92f)
                        )
                        Text(
                            text = "$achievedCount / ${profile.dailyTarget} Leads ($percentage%)",
                            fontFamily = JetBrainsMono,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF6EE7B7)
                        )
                    }

                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(999.dp)),
                        color = EmeraldGreenBright,
                        trackColor = PureWhite.copy(alpha = 0.22f),
                        strokeCap = StrokeCap.Round
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "$approvedCount sanctioned today",
                            style = MaterialTheme.typography.labelSmall,
                            color = PureWhite.copy(alpha = 0.78f)
                        )
                        Text(
                            text = if (achievedCount >= profile.dailyTarget) "Target achieved" else "${profile.dailyTarget - achievedCount} remaining",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFBFDBFE)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DipHoldAlertBanner(
    dipCount: Int,
    onReviewClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dip_hold_alert_banner")
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onReviewClick),
        color = AmberContainer,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(AmberWarning.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.WarningAmber,
                    contentDescription = "DIP Hold Alert",
                    tint = AmberWarning,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "$dipCount Application${if (dipCount > 1) "s" else ""} on DIP Hold",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = AmberOnContainer
                )
                Text(
                    text = "Re-upload KYC / income proofs to clear underwriting holds",
                    style = MaterialTheme.typography.bodySmall,
                    color = AmberOnContainer.copy(alpha = 0.85f)
                )
            }
            Text(
                text = "Resolve",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = AmberWarning
            )
        }
    }
}

@Composable
private fun StatusFilterBar(
    selectedStatus: ApplicationStatus?,
    onSelectStatus: (ApplicationStatus?) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        item(key = "all") {
            FilterChip(
                selected = selectedStatus == null,
                onClick = { onSelectStatus(null) },
                label = { Text("All") },
                modifier = Modifier.testTag("filter_chip_all"),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = RoyalBlue,
                    selectedLabelColor = PureWhite
                )
            )
        }
        items(ApplicationStatus.entries, key = { it.name }) { status ->
            FilterChip(
                selected = selectedStatus == status,
                onClick = { onSelectStatus(status) },
                label = { Text(status.shortLabel) },
                modifier = Modifier.testTag("filter_chip_${status.name.lowercase()}"),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = RoyalBlue,
                    selectedLabelColor = PureWhite
                )
            )
        }
    }
}

@Composable
private fun SectionScreenHeader(
    title: String,
    subtitle: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun EmptyApplicationsState(
    isDipQueue: Boolean,
    onStartNewLead: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(if (isDipQueue) EmeraldContainer else RoyalBlueContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isDipQueue) Icons.Rounded.VerifiedUser else Icons.Rounded.Search,
                    contentDescription = null,
                    tint = if (isDipQueue) EmeraldGreen else RoyalBlue,
                    modifier = Modifier.size(28.dp)
                )
            }
            Text(
                text = if (isDipQueue) "All DIP Holds Cleared" else "No Matching Applications",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (isDipQueue) {
                    "Zero pending document discrepancies across your territory."
                } else {
                    "Try clearing your search or start a fresh credit card application."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!isDipQueue) {
                Button(
                    onClick = onStartNewLead,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Application")
                }
            }
        }
    }
}
