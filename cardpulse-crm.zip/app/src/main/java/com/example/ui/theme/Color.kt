package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Corporate Palette — Royal Blue, Crisp White, Slate Gray, Emerald Green
val RoyalBlue = Color(0xFF1E3A8A)
val RoyalBlueDark = Color(0xFF172554)
val RoyalBlueLight = Color(0xFF2563EB)
val RoyalBlueContainer = Color(0xFFDBEAFE)
val RoyalBlueSurfaceTint = Color(0xFFEFF6FF)

val EmeraldGreen = Color(0xFF059669)
val EmeraldGreenBright = Color(0xFF10B981)
val EmeraldContainer = Color(0xFFECFDF5)
val EmeraldOnContainer = Color(0xFF065F46)

val AmberWarning = Color(0xFFD97706)
val AmberContainer = Color(0xFFFEF3C7)
val AmberOnContainer = Color(0xFF92400E)

val CrimsonError = Color(0xFFDC2626)
val CrimsonContainer = Color(0xFFFEF2F2)
val CrimsonOnContainer = Color(0xFF991B1B)

val IndigoInfo = Color(0xFF4F46E5)
val IndigoContainer = Color(0xFFEEF2FF)
val IndigoOnContainer = Color(0xFF3730A3)

val CyanReview = Color(0xFF0284C7)
val CyanContainer = Color(0xFFE0F2FE)
val CyanOnContainer = Color(0xFF075985)

// Neutrals (Slate Scale)
val PureWhite = Color(0xFFFFFFFF)
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate500 = Color(0xFF64748B)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)

// Dark Theme Palette
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkRoyalBluePrimary = Color(0xFF60A5FA)
val DarkRoyalBlueContainer = Color(0xFF1E3A8A)
val DarkEmeraldPrimary = Color(0xFF34D399)
val DarkEmeraldContainer = Color(0xFF064E3B)
