package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = RoyalBlue,
    onPrimary = PureWhite,
    primaryContainer = RoyalBlueContainer,
    onPrimaryContainer = RoyalBlueDark,
    secondary = EmeraldGreen,
    onSecondary = PureWhite,
    secondaryContainer = EmeraldContainer,
    onSecondaryContainer = EmeraldOnContainer,
    tertiary = AmberWarning,
    onTertiary = PureWhite,
    tertiaryContainer = AmberContainer,
    onTertiaryContainer = AmberOnContainer,
    error = CrimsonError,
    onError = PureWhite,
    errorContainer = CrimsonContainer,
    onErrorContainer = CrimsonOnContainer,
    background = Slate50,
    onBackground = Slate900,
    surface = PureWhite,
    onSurface = Slate900,
    surfaceVariant = Slate100,
    onSurfaceVariant = Slate600,
    outline = Slate300,
    outlineVariant = Slate200
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkRoyalBluePrimary,
    onPrimary = RoyalBlueDark,
    primaryContainer = DarkRoyalBlueContainer,
    onPrimaryContainer = RoyalBlueContainer,
    secondary = DarkEmeraldPrimary,
    onSecondary = EmeraldOnContainer,
    secondaryContainer = DarkEmeraldContainer,
    onSecondaryContainer = EmeraldContainer,
    tertiary = AmberWarning,
    onTertiary = Slate900,
    tertiaryContainer = AmberOnContainer,
    onTertiaryContainer = AmberContainer,
    error = CrimsonError,
    onError = PureWhite,
    errorContainer = CrimsonOnContainer,
    onErrorContainer = CrimsonContainer,
    background = DarkBackground,
    onBackground = Slate50,
    surface = DarkSurface,
    onSurface = Slate50,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Slate300,
    outline = Slate600,
    outlineVariant = Slate700
)

val CardPulseShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun CardPulseTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = CardPulseTypography,
        shapes = CardPulseShapes,
        content = content
    )
}
